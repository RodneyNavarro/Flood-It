import java.io.Serializable;

public class GenericLinkedStack<E> implements Stack<E>, Serializable{
  
  
  private int size;
  private Elem head;
  
  private class Elem implements Serializable{
    private E val;
    private Elem next;
  }
  
  public GenericLinkedStack() {
    head = null;
    size = 0;
  }
  
  public boolean isEmpty() {
    return (head == null);
  }
  
  public E peek(){
    return head.val;
  }
  
  public E pop() {
    
    if (isEmpty()) {
      throw new EmptyStackException("Empty stack");
    }
    
    Elem temp = head;
    head = head.next;
    size--;
    return temp.val;
  }
  
  public void push( E elem ) {
    if (elem == null) {
      throw new NullPointerException("Cannot stack a null object");
    }
    Elem temp = head;
    head = new Elem();
    head.val = elem;
    head.next = temp;
    size++;
  }
 
}