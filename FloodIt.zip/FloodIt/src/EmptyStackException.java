public class EmptyStackException extends IllegalStateException {

    public EmptyStackException() {
        super();
    }

    public EmptyStackException(String message) {
        super(message);
    }
    
}
